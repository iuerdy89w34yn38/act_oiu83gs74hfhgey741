<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    
  <?php include"include/head.php" ?>

  <title>Dashboard sales - Modern Admin - Clean Bootstrap 4 Dashboard HTML Template + Bitcoin
    Dashboard
  </title>
  
</head>
<body class="vertical-layout vertical-menu-modern 2-columns   menu-expanded fixed-navbar"
data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">
  
<?php $link="index.php"; ;?>

  
<?php include"include/header.php" ?>
<?php include"include/sidebar.php" ?>

<div class="app-content content">
  <div class="content-wrapper">


  	
  </div>
</div>

<?php include"include/footer.php" ?>

</body>
</html>