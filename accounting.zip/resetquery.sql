UPDATE acts set balance = 0;
TRUNCATE TABLE itemslog;
TRUNCATE TABLE ledger;
TRUNCATE TABLE journal;
TRUNCATE TABLE customers;
TRUNCATE TABLE vendors;
TRUNCATE TABLE items;
TRUNCATE TABLE itemsb;

