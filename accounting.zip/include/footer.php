
<!-- BEGIN VENDOR JS-->
<script src="vendors/js/vendors.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="vendors/js/charts/chart.min.js" type="text/javascript"></script>
<script src="vendors/js/charts/raphael-min.js" type="text/javascript"></script>
<script src="vendors/js/charts/morris.min.js" type="text/javascript"></script>
<script src="vendors/js/charts/jvector/jquery-jvectormap-2.0.3.min.js"
type="text/javascript"></script>
<script src="vendors/js/charts/jvector/jquery-jvectormap-world-mill.js"
type="text/javascript"></script>
<script src="data/jvector/visitor-data.js" type="text/javascript"></script>
<script src="vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script>
<script src="vendors/js/forms/select/select2.full.min.js" type="text/javascript"></script>



<!-- END PAGE VENDOR JS-->
<!-- BEGIN MODERN JS-->
<script src="js/core/app-menu.js" type="text/javascript"></script>
<script src="js/core/app.js" type="text/javascript"></script>
<script src="js/scripts/customizer.js" type="text/javascript"></script>
<!-- END MODERN JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="js/scripts/pages/dashboard-sales.js" type="text/javascript"></script>

<script src="js/scripts/tables/datatables-extensions/datatables-sources.js"
type="text/javascript"></script>

<script src="js/scripts/tables/datatables-extensions/datatable-select.js"></script>

<script src="vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script>
<script src="vendors/js/tables/datatable/dataTables.responsive.min.js"
type="text/javascript"></script>
<script src="vendors/js/tables/datatable/dataTables.select.min.js"
type="text/javascript"></script>
<script src="vendors/js/tables/datatable/dataTables.buttons.min.js"
type="text/javascript"></script>
<script src="vendors/js/tables/datatable/buttons.bootstrap4.min.js"
type="text/javascript"></script>

<script src="js/scripts/tables/datatables/datatable-advanced.js"></script>
<script src="vendors/js/tables/buttons.flash.min.js" type="text/javascript"></script>
<script src="vendors/js/tables/jszip.min.js" type="text/javascript"></script>
<script src="vendors/js/tables/pdfmake.min.js" type="text/javascript"></script>
<script src="vendors/js/tables/vfs_fonts.js" type="text/javascript"></script>
<script src="vendors/js/tables/buttons.html5.min.js" type="text/javascript"></script>
<script src="vendors/js/tables/buttons.print.min.js" type="text/javascript"></script>
  

<script src="vendors/js/tables/datatable/dataTables.select.min.js" type="text/javascript"></script>

<script src="js/scripts/forms/select/form-select2.js" type="text/javascript"></script>
<script src="js/scripts/modal/components-modal.js" type="text/javascript"></script>

<script src="js/scripts/tables/datatables-extensions/datatable-button/datatable-html5.js"
type="text/javascript"></script>

<script src="js/scripts/tables/datatables/datatable-api.js" type="text/javascript"></script>


<script src="vendors/js/forms/icheck/icheck.min.js" type="text/javascript"></script>
<script src="js/scripts/forms/checkbox-radio.js" type="text/javascript"></script>


<script src="js/scripts/modal/components-modal.js" type="text/javascript"></script>

<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


<!-- END PAGE LEVEL JS-->

